class CodeResult:
    def __init__(self, lOriginal, lCode, temps):
        self.lOriginal = lOriginal
        self.lCode = lCode
        self.temps = temps
